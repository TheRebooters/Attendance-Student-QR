# AttendanceQR
A web app developed for managing attendance using QR code

### Tech Stack Used
HTML, CSS, VanillaJS, PHP, Bootstrap, jQuery

### Prerequisite
1. Apache Sever and PhpMyAdmin [Used in this project]
2. Make a database with attendanceqr name in phpmyadmin
3. Import the db file [ attendanceqr.sql ] & you will be all set with the tables [attendance, users]
4. Passwords are md5 encrpted and you will get admin user by default with hashed password
5. Just change that password with your preferred md5 password then you will be good to go
6. Login with your creds

### App Link
https://attendanceqr.tmalikjk14.online/

### Credentials
1. Admin: admin, Admin666@
2. Regular: aditivats, aditivats [Can mark between 9:00 AM - 11:00 AM {Note: Can be changed by admin}]
3. Full: ramansharma, ramansharma, yogesh, yogesh
4. Restricted: aayush, aayush
